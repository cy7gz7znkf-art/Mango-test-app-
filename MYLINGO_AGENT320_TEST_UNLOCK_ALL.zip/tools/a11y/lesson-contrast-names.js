const { chromium } = require('playwright');
const fs=require('fs');
const path=require('path');const ROOT=path.resolve(__dirname,'..','..');
const BASE=process.env.BASE||'http://localhost:8765/';
const OUT=process.env.OUT||'/tmp/lesson_audit.json';
const levels=['a1','a2','b1','b2','c1','c2'];
const contrastFn=require('./contrast-fn.js');
const namesFn=`(function(){var out=[];
function rendered(e){return e.offsetParent!==null||e.getClientRects().length>0}
document.querySelectorAll('button,a[href],input,select,textarea,[role=button],[role=tab],[role=progressbar],img,svg[role=img],video,audio,iframe').forEach(function(e){
if(!rendered(e))return;
var n=(e.getAttribute('aria-label')||'').trim()||(e.getAttribute('aria-labelledby')?'x':'')||(e.textContent||'').trim()||(e.getAttribute('title')||'').trim()||(e.tagName==='IMG'?(e.hasAttribute('alt')?'ok':''):'')||(e.id&&document.querySelector('label[for="'+e.id+'"]')?'x':'');
if(e.tagName==='IMG'&&e.getAttribute('alt')==='')return;
if(!n)out.push(e.outerHTML.slice(0,100))});
var h1=[].slice.call(document.querySelectorAll('h1')).filter(rendered).length;
var main=[].slice.call(document.querySelectorAll('main,[role=main]')).filter(rendered).length;
var ids={};document.querySelectorAll('[id]').forEach(function(e){ids[e.id]=(ids[e.id]||0)+1});var dup=Object.keys(ids).filter(function(k){return ids[k]>1});
var tiny=[];document.querySelectorAll('button,a[href],[role=tab],[role=button],input,select').forEach(function(e){if(!rendered(e))return;var r=e.getBoundingClientRect();if(r.width&&r.height&&(r.width<24||r.height<24)){var cs=getComputedStyle(e);if(cs.display!=='inline')tiny.push(e.tagName+':'+(e.textContent||e.getAttribute('aria-label')||'').trim().slice(0,20)+' '+Math.round(r.width)+'x'+Math.round(r.height))}});
return {unnamed:out,h1:h1,main:main,dupIds:dup,tiny:tiny,overflow:document.documentElement.scrollWidth>document.documentElement.clientWidth+1}})()`;
(async()=>{
  const b=await chromium.launch();
  const results=[];const pages=[];
  const seed={};
  for(const L of levels){
    const lessons=JSON.parse(fs.readFileSync(`${ROOT}/course_content/lessons/${L}.json`));
    for(const l of lessons){ if(l.status!=='published')continue;
      (l.exercise_quiz_ids||[]).concat(l.lesson_quiz_id?[l.lesson_quiz_id]:[]).forEach(id=>seed[id]={status:'completed',best:100,percent:100,attempts:1});
      pages.push({L,id:l.lesson_id});}
  }
  const only=process.env.ONLY?process.env.ONLY.split(','):null;
  for(const scheme of ['light','dark']){
   for(const [w,h] of [[390,844],[320,700]]){
    const ctx=await b.newContext({colorScheme:scheme,viewport:{width:w,height:h}});
    // Agent 255: video slide 0 locks Continue until 90% watched (YouTube unreachable here); use the app's own offline fallback so every slide is reachable.
    await ctx.addInitScript(()=>{Object.defineProperty(navigator,'onLine',{get:()=>false})});
    await ctx.addInitScript(s=>{try{localStorage.setItem('mylingo.progress.v1',JSON.stringify(s))}catch(e){}},seed);
    for(const p of pages){
      if(only&&!only.includes(p.id))continue;
      const pg=await ctx.newPage();const errs=[];
      pg.on('pageerror',e=>errs.push('pageerror '+e.message));
      // youtube.com is unreachable from the sandbox (403) — network artifact, not an app defect.
      pg.on('console',m=>{if(m.type()==='error'&&!/status of 403/.test(m.text()))errs.push('console '+m.text())});
      pg.on('requestfailed',r=>{if(!/youtube\.com/.test(r.url()))errs.push('reqfail '+r.url())});
      const url=`${BASE}courses/lesson.html?lesson=${p.id}&level=${p.L}`;
      await pg.goto(url,{waitUntil:'networkidle'}).catch(e=>errs.push('goto '+e.message));
      await pg.waitForTimeout(300);
      const state=await pg.evaluate(()=>({err:!!document.querySelector('.errbox,.error,#error'),txt:document.body.innerText.slice(0,80),tabs:[...document.querySelectorAll('.trail-item,[role=tab]')].map(t=>t.textContent.trim())}));
      const rec={p:p.id,scheme,w,slides:[],errs};
      const nTabs=Math.max(1,state.tabs.length);
      for(let i=0;i<nTabs;i++){
        // Agent 255: the trail is now nav buttons (Agent 26), gated by maxReached — advance with the real Continue button instead.
        if(i>0){const nx=pg.locator('#navNext');if(await nx.count()){await nx.click().catch(()=>{});await pg.waitForTimeout(200)}}
        const c=await pg.evaluate(contrastFn);const n=await pg.evaluate(namesFn);
        rec.slides.push({i,label:state.tabs[i],contrast:c,names:n});
      }
      rec.first=state.txt;
      results.push(rec);await pg.close();
    }
    await ctx.close();
   }
  }
  await b.close();
  fs.writeFileSync(OUT,JSON.stringify(results,null,1));
  let bad=0;
  for(const r of results){const issues=[];
    if(r.errs.length)issues.push('errs:'+r.errs.join('|'));
    r.slides.forEach(s=>{const cr=s.contrast.filter(x=>x.sel!=='span.sep');if(cr.length)issues.push(`s${s.i} contrast:`+JSON.stringify(cr.slice(0,3)));if(s.names.unnamed.length)issues.push(`s${s.i} unnamed:`+s.names.unnamed.slice(0,2).join(';'));if(s.names.h1!==1)issues.push(`s${s.i} h1=${s.names.h1}`);if(s.names.main!==1)issues.push(`s${s.i} main=${s.names.main}`);if(s.names.dupIds.length)issues.push(`s${s.i} dup ${s.names.dupIds}`);if(s.names.overflow)issues.push(`s${s.i} overflow`)});
    if(issues.length){bad++;console.log(r.p,r.scheme,r.w,issues.join(' ; ').slice(0,400))}}
  console.log('runs',results.length,'with issues',bad);
})();
